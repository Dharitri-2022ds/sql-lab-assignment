use supply_db ;

/*
Question : Golf related products

List all products in categories related to golf. Display the Product_Id, Product_Name in the output. Sort the output in the order of product id.
Hint: You can identify a Golf category by the name of the category that contains golf.

*/
select Product_Name,Product_Id
 from 
 (
 select pi.Product_Name,pi.Product_Id
 from product_info as pi
 left join category as c
 on pi.Category_Id = c.Id
 where Lower(c.Name) like '%golf%'
 order by Product_Id
 ) as summary;
-- **********************************************************************************************************************************

/*
Question : Most sold golf products

Find the top 10 most sold products (based on sales) in categories related to golf. Display the Product_Name and Sales column in the output. Sort the output in the descending order of sales.
Hint: You can identify a Golf category by the name of the category that contains golf.

HINT:
Use orders, ordered_items, product_info, and category tables from the Supply chain dataset.


*/
select Product_Name, Sales
from
(
select 
pi.Product_Name,sum(Sales) as Sales,
rank()over(order by sum(Sales) desc) as Sales_Rank
from
orders as o
left join ordered_items as ord_itm
on o.Order_Id = ord_itm.Order_Id
left join product_info as pi
on ord_itm.Item_Id = pi.Product_Id
left join category as c
on pi. Category_Id = c.Id
where LOWER(c.Name) like '%golf%'
group by 1
order by 2 desc
) as summary
where Sales_Rank <=10;
-- **********************************************************************************************************************************

/*
Question: Segment wise orders

Find the number of orders by each customer segment for orders. Sort the result from the highest to the lowest 
number of orders.The output table should have the following information:
-Customer_segment
-Orders


*/
select 
cust.Segment as customer_segment,
count(o.Order_Id) as Orders
from 
orders as o
left join customer_info as cust
on o.Customer_Id = cust.Id
group by 1
order by Orders desc;
-- **********************************************************************************************************************************
/*
Question : Percentage of order split

Description: Find the percentage of split of orders by each customer segment for orders that took six days 
to ship (based on Real_Shipping_Days). Sort the result from the highest to the lowest percentage of split orders,
rounding off to one decimal place. The output table should have the following information:
-Customer_segment
-Percentage_order_split

HINT:
Use the orders and customer_info tables from the Supply chain dataset.


*/
WITH Seg_Orders as
(
select
cust.Segment as customer_segment,
count(o.Order_Id) as Orders
from
orders as o
left join customer_info as cust
on o.Customer_Id = cust.Id
where Real_Shipping_Days = 6
group by 1
)
select
a.customer_segment,
round(a.Orders/sum(b.Orders) * 100,1) as Percentage_order_split
from
Seg_Orders as a
join
Seg_Orders as b
group by 1
order by 2 desc;
-- **********************************************************************************************************************************
